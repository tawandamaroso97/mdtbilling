# MDT Billing — Quotations & Invoicing

A standalone quotation-to-cash system for Marrs Digital Technology: create quotations,
convert accepted ones into invoices, track payments, and see collections/aging analytics.
Multiple people can sign in from different computers at once. Fully white-label —
company details, currency, and theme colors are editable in Settings.

The project has two parts:

- **`server/`** — Node.js/Express API with a built-in SQLite database (no external database
  service to set up). Handles logins, clients, quotations, invoices, and payments.
- **`client/`** — React app (built with Vite) that people actually use in the browser.

---

## 1. Run it locally (fastest way to try it out)

You'll need [Node.js](https://nodejs.org) 18 or newer installed.

**Start the backend:**
```bash
cd server
cp .env.example .env      # edit JWT_SECRET to a long random string
npm install
npm start
```
This starts the API at `http://localhost:4000`. A `data/` folder with the SQLite database
file is created automatically on first run.

**Start the frontend** (in a new terminal):
```bash
cd client
cp .env.example .env      # leave as-is for local use
npm install
npm run dev
```
This opens the app at `http://localhost:5173`.

Open that URL in your browser. The first time, you'll be asked to create the first admin
account — that's you. After that, go to **Settings → Team** to add the rest of your staff
so each person can sign in from their own computer with their own login.

---

## 2. Making it available to multiple computers on your network

If everyone is in the same office, the simplest option: run the backend and frontend on
one computer (or a small always-on machine / Raspberry Pi), then have colleagues open
`http://<that-computer's-IP-address>:5173` in their browser. You'll need to:

1. In `server/.env`, set `FRONTEND_ORIGIN` to `http://<that-computer's-IP>:5173`
2. In `client/.env`, set `VITE_API_URL` to `http://<that-computer's-IP>:4000/api`
3. Restart both

## 3. Putting it on the internet (recommended for a real team/multiple locations)

For anyone to reach it from anywhere — not just the office network — deploy the two parts
to a hosting provider. A straightforward, low-cost route:

1. **Push this project to a GitHub repository** (private is fine).
2. **Deploy `server/`** to a Node-friendly host such as [Render](https://render.com),
   [Railway](https://railway.app), or a small VPS:
   - Build command: `npm install`
   - Start command: `npm start`
   - Set environment variables `JWT_SECRET` (long random string), `FRONTEND_ORIGIN`
     (your deployed frontend URL, added after step 3), and optionally `DB_PATH`.
   - **Important:** SQLite writes to a file, so make sure your host's disk is persistent
     (Render's "Persistent Disk" add-on, Railway volumes, or any VPS). Without persistent
     storage your data will be wiped on redeploys.
3. **Deploy `client/`** to a static host such as [Vercel](https://vercel.com) or
   [Netlify](https://netlify.com):
   - Build command: `npm run build`
   - Output directory: `dist`
   - Set environment variable `VITE_API_URL` to your deployed backend's URL + `/api`
     (e.g. `https://mdt-billing-api.onrender.com/api`)
4. Once both are live, open the frontend URL, complete the first-run admin setup, then
   invite your team from **Settings → Team**.

You'll end up with something like `https://billing.mdt.co.zw` (once you point your own
domain at it) that anyone on your team can log into from any computer.

---

## Everyday use

- **Clients** → add companies you quote and bill.
- **Quotations** → create, send, mark Accepted/Rejected, then **Convert to invoice** once
  a client agrees.
- **Invoices** → record part or full payments as they come in; status updates automatically
  (Sent → Partially paid → Paid, or Overdue if past due date and unpaid).
- **Dashboard** → collections, outstanding balance, aging report, win rate, top clients.
- **Settings** → company details, bank/EcoCash details, tax rate, numbering, and full theme
  colors — change these to re-brand the whole app for another company.
- **Team** (admin only) → add/remove staff logins, promote to admin, disable access.

## Selling this to other companies

Because company branding and theme colors live in the database (not hardcoded), you can
stand up a **separate deployment per client** (their own server + database + Settings),
each fully re-branded in a couple of minutes. That's the simplest form of white-labeling
with this architecture. Turning it into a single multi-tenant SaaS product (one deployment
serving many companies with data walls between them) is a further step — happy to help
scope that out if/when you're ready to sell it that way.

## Security notes before going live

- Always set a strong, random `JWT_SECRET` in production — never use the example value.
- Serve both frontend and backend over HTTPS (Render/Vercel/Netlify give you this for free).
- Back up the `server/data/mdt-billing.db` file regularly if you're on a VPS.
